#Hello world
I am Liam, the maker of the golang markdown lexer known as "go-mdlx"
##About me
I am 13 years old, I *love* golang, and I write `code`.
##About this lexer/parser
It was developed under the concepts created by Rob Pike.
When I tried to create this lexer without those ideas...
*And it was TERRIBLE*. Before this, I didn't know how to properly write a lexer, and it didn't work well, nor tokenize.
Look at it before it's *gone*.
###The new lexer :)
To be short, it is _awesome_. I am super happy with it
